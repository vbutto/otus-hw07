@echo off
setlocal

echo === Packing functions (no deps) ===

if exist weather_context.zip del weather_context.zip
if exist weather_forecast.zip del weather_forecast.zip

for %%F in (function1_weather_context.py function2_weather_forecast.py) do (
  if not exist "%%F" (
    echo [ERROR] Missing %%F
    exit /b 1
  )
)

powershell -NoProfile -Command "Compress-Archive -Path function1_weather_context.py -DestinationPath weather_context.zip -Force"
if errorlevel 1 (
  echo [ERROR] zip weather_context.zip failed
  exit /b 1
)

powershell -NoProfile -Command "Compress-Archive -Path function2_weather_forecast.py -DestinationPath weather_forecast.zip -Force"
if errorlevel 1 (
  echo [ERROR] zip weather_forecast.zip failed
  exit /b 1
)

echo Done. Created: weather_context.zip, weather_forecast.zip
endlocal
